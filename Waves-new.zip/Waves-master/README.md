<p align="center">
  <img src="docs/square.png" width="112" alt="">
</p>

<h1 align="center">Waves</h1>

<p align="center">
  An unofficial Android music client for Spotify Premium and YouTube Music,
  built in Liquid Glass. Search it by how you feel.
</p>

<p align="center">
  <a href="https://github.com/Lelonio/Square/releases/latest"><img src="https://img.shields.io/github/v/release/Lelonio/Square?label=release" alt="Latest release"></a>
  <a href="https://github.com/Lelonio/Square/releases"><img src="https://img.shields.io/github/downloads/Lelonio/Square/total" alt="Downloads"></a>
  <img src="https://img.shields.io/badge/Android-8.0%2B-3DDC84" alt="Android 8.0 or later">
  <a href="LICENSE"><img src="https://img.shields.io/github/license/Lelonio/Square" alt="Licence"></a>
</p>

<p align="center">
  <a href="#download"><b>Download</b></a> ·
  <a href="#features"><b>Features</b></a> ·
  <a href="#first-launch"><b>First launch</b></a> ·
  <a href="#faq"><b>FAQ</b></a> ·
  <a href="https://t.me/+-XDmbFwz7uBkMjc0"><b>Telegram community</b></a> ·
  <a href="docs/DEVELOPMENT.md"><b>Building</b></a>
</p>

| Player | Lyrics | Effects |
| :---: | :---: | :---: |
| ![The player](docs/screenshots/player-2.png) | ![Synced lyrics](docs/screenshots/lyrics-2.png) | ![The effects panel](docs/screenshots/effects-2.png) |
| **Artist** | **Album** | **Glass settings** |
| ![An artist's page](docs/screenshots/artist-2.png) | ![An album](docs/screenshots/album-2.png) | ![The glass settings](docs/screenshots/glass-3.png) |

## Features

### Two sources, one app

- **Spotify or YouTube Music**, chosen at first launch and switchable in the
  settings. Home, search, the library and the player work the same on both.
- **Spotify**: your own account, with its playlists, library and Connect
  devices. Needs Premium.
- **YouTube Music**: the whole catalogue and the music videos, with no account
  needed. Sign in with Google to bring in your playlists, albums and followed
  artists.

### Player

- The cover or the song's looping canvas video behind the controls.
- Music videos: switch from the song to its video in place, without losing the
  queue or the position, and keep watching in picture-in-picture.
- Radio from any song, and autoplay of similar songs when the queue ends.
- Crossfade between songs, with an option to skip trailing silence.
- Sleep timer: after 5 to 60 minutes or at the end of the song, fading out
  before it stops.

### Audio effects

- Speed and pitch, each on its own, plus reverb.
- Presets, so "slowed + reverb" is one tap on any song.
- Karaoke: turn the voice down.
- Streaming quality that follows the connection, or a fixed one.

### Lyrics

- Synced lyrics, word by word where they exist and line by line otherwise.
- Translation into your language, under the original lines.

### Library and discovery

- Playlists, albums, artists and liked songs. Create, rename and delete
  playlists, add and remove songs, pin favourites, follow artists.
- A home page of shelves made for you, a **New** tab with releases and charts,
  and a **Radio** tab of stations, moods and genres.
- Search, with your recent searches kept (swipe one away to remove it).
- The music already on your phone, in a Local files shelf.

### Offline

- Download playlists, albums and songs, from either source. A song kept by two
  playlists is downloaded once.
- Downloads over Wi-Fi only, and automatic downloads of your liked songs.
- Offline mode: play only what is on the phone.

### Spotify extras

- A **Connect** device: send playback to Square from any other device, and
  control your other devices from it.
- What your friends are listening to.
- Similar playlists at the end of each playlist.
- Song credits: performers, writers and producers.
- What you play is saved to your listening history, as it would be anywhere
  else you listen.
- Spotify links can open straight in Square.

### Android Auto

- Browse playlists and recently played, search by voice, like a song or start a
  radio from the car.

### Look and language

- Every control, the tab bar, the player, the sheets and the menus are made of
  one refracting glass. Blur, refraction and tint are adjustable, with a lighter
  mode for slower phones.
- Twelve languages: English, Italian, Spanish, French, German, Portuguese,
  Russian, Turkish, Hindi, Korean, Japanese and Vietnamese, chosen independently
  of the phone's own.

## Download

[![Get it on Orion Store](https://raw.githubusercontent.com/RookieEnough/Orion-Store/refs/heads/main/assets/orion-badge.png)](https://rookieenough.github.io/Orion-Data/redirect.html?id=square)

Or

Download the APK from the [latest release](https://github.com/Lelonio/Square/releases/latest)
and install it. Square needs Android 8.0 or later.

Square updates itself: it checks for new releases and installs them from the
settings. It is not on the Play Store and cannot be; see the
[disclaimer](#disclaimer).

<details>
<summary><b>The first minutes after installing are slower</b></summary>

Android takes a while to optimise a freshly installed app, and until it does
the interface is noticeably slower. To do it straight away, open the app once
and give it a few seconds, then run this with the phone connected:

```bash
adb shell cmd package compile -m speed-profile -f dev.lelonio.square
```

Run before the app has been opened, the command finds nothing to compile.

</details>

## First launch

Square first asks where the music should come from. You can change it later in
the settings.

- **YouTube Music** plays straight away. Signing in with Google, from the
  settings, is optional.
- **Spotify** needs a Premium account and a few minutes of guided setup: you
  sign in, then register a free app of your own in Spotify's developer
  dashboard and paste its client ID. Search and a few other features go
  through Spotify's Web API, which limits requests per app, so with your own
  app the limit is yours alone. The setup walks you through every step.

## FAQ

**Square does not appear in Android Auto.**
Android Auto only lists apps installed from the Play Store. Turn on "Unknown
sources" in Android Auto's developer settings and Square shows up.

**Can I use a free Spotify account?**
No. A free account can sign in, but Spotify only streams to a client like this
one with Premium. YouTube Music works with no account at all.

**YouTube Music search works, but songs do not play.**
YouTube changes how its streams are served every so often. Update to the
latest release, which is usually where the fix is.

## Disclaimer

Square is not affiliated with, endorsed by or connected to Spotify or Google.
Both sources are used on terms they do not offer: Square re-implements
Spotify's protocol, which Spotify's Terms of Service forbid, and reads YouTube
Music through the private endpoints its own web client uses. It cannot be
published on the Play Store, and you use it at your own risk. There is no
warranty of any kind; see the licence.

## Help and feedback

- **Telegram community**: [join Square | Community](https://t.me/+-XDmbFwz7uBkMjc0) for questions, feedback, bug reports and feature requests.
- **Release announcements**: [Square | Official](https://t.me/SquareAppOfficial) automatically shares new APKs and release notes from GitHub.
- **Questions** (how something works, how to set it up): [Discussions, Q&A](https://github.com/Lelonio/Square/discussions/categories/q-a)
- **Ideas and requests**: [Discussions, Ideas](https://github.com/Lelonio/Square/discussions/categories/ideas)
- **Something broken**: [open an issue](https://github.com/Lelonio/Square/issues/new/choose). If the app closed or froze, attach a report from Settings → About → Save a report.

The same two links are in the app, under Settings → About.

## Support

Square is free and has no ads. If it is useful to you, you can support its
development on [Ko-fi](https://ko-fi.com/lelonio).

## Credits

| Project | Licence | How it is used |
| --- | --- | --- |
| [librespot](https://github.com/librespot-org/librespot) | MIT | The Spotify engine. `librespot-core`, `librespot-playback` and `librespot-connect` are vendored with local patches. |
| [Spotify Web Playback SDK](https://developer.spotify.com/documentation/web-playback-sdk) | Spotify Developer Terms | Playback for accounts Spotify refuses audio keys, through the listener's own developer app. |
| [Metrolist](https://github.com/mostafaalagamy/Metrolist) | GPL-3.0 | Its InnerTube client, vendored as [`innertube/`](innertube/), because it is published nowhere else. Powers the signed-in YouTube Music library. |
| [NewPipeExtractor](https://github.com/TeamNewPipe/NewPipeExtractor) | GPL-3.0 | Anonymous YouTube Music search and stream URLs. |
| [lossless.wtf](https://lossless.wtf) | n/a | Synced lyrics timed to the word, asked first on both sources. |
| [LrcLib](https://lrclib.net) | n/a | Synced lyrics for the YouTube Music source, over its open API. |
| [Spicy Lyrics](https://github.com/Spikerko/spicy-lyrics) | AGPL-3.0 | The lyrics animation, ported to Compose by [@donutnotnut](https://github.com/donutnotnut) in [#50](https://github.com/Lelonio/Square/discussions/50). |
| [Bungee](https://github.com/kupix/bungee) | MPL-2.0 | Time stretching, fetched at build time. |
| [AndroidLiquidGlass](https://github.com/Kyant0/AndroidLiquidGlass) | Apache-2.0 | The glass material; the catalog components are copied with their notice. |
| [Phosphor Icons](https://phosphoricons.com) | MIT | Every icon in the app. |
| [ebur128](https://github.com/sdroege/ebur128) | MIT | Loudness of local files, so they play at the level of the streamed tracks. |
| librespot-java | Apache-2.0 | The listening-event format, re-implemented from its `EventService` rather than copied. |
| [go-librespot](https://github.com/devgianlu/go-librespot) and [go-librespot-termux](https://github.com/SEKY443/go-librespot-termux) | GPL-3.0 | The remote sleep timer's command and state fields, the check on truncated audio keys, and how Spotify's DJ is resolved and voiced (the session service, `client-tts`, the narration metadata), re-implemented from their findings rather than copied. |

## Building from source

Requirements, build steps, signing, the architecture and notes on the code are
in [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md).

## Licence

GPL-3.0-or-later. See [LICENSE](LICENSE).

The lyrics view,
[`LyricsView.kt`](app/src/main/java/dev/lelonio/square/ui/player/LyricsView.kt),
is ported from Spicy Lyrics and stays under AGPL-3.0, combined with the rest as
section 13 of both licences allows.

## Star History

<a href="https://www.star-history.com/?repos=lelonio%2Fsquare&type=date&legend=top-left">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/chart?repos=lelonio/square&type=date&theme=dark&legend=top-left" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/chart?repos=lelonio/square&type=date&legend=top-left" />
   <img alt="Star History Chart" src="https://api.star-history.com/chart?repos=lelonio/square&type=date&legend=top-left" />
 </picture>
</a>


## Waves changes (redesign of Square)

- **Feeling search.** Type how you feel ("I miss her and can't stop crying",
  "rainy and cozy", "need to focus") and a card at the top of the results says
  what Waves heard, with songs that fit. The feeling is read on the phone by
  `data/FeelingInterpreter.kt` and turned into ordinary catalogue searches that
  go through the same `backend.search` as every other query. The normal results
  stay underneath, so searching a song or artist by name works as before.
- **New identity.** Name, wordmark, icon, palette (deep water / foam, sea-glass
  accent) and serif display type. Screens and the glass components are Square's.
- **Untouched on purpose.** Package name and application id, the Spotify and
  YouTube backends, the gateway and OAuth code, lyrics providers (including
  their User-Agent strings), downloads, playback and Android Auto.

Adding a language to feeling search means adding phrases to `MOODS` in
`FeelingInterpreter.kt`; `FeelingInterpreterTest` shows the expected behaviour.
