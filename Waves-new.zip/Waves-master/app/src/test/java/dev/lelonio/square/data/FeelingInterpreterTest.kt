package dev.lelonio.square.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FeelingInterpreterTest {

    @Test fun `a sentence about heartbreak is heartbreak`() {
        assertEquals("heartbreak", FeelingInterpreter.interpret("I miss her so much and I can't stop crying")?.id)
    }

    @Test fun `a song title is not a feeling`() {
        assertNull(FeelingInterpreter.interpret("Blinding Lights"))
        assertNull(FeelingInterpreter.interpret("taylor swift"))
        assertNull(FeelingInterpreter.interpret("Saddle up"))
    }

    @Test fun `every home chip reads back as its own feeling`() {
        for (feeling in FeelingInterpreter.all) {
            val back = FeelingInterpreter.interpret(feeling.queries.first())
            assertNotNull("${feeling.id}: ${feeling.queries.first()}", back)
            assertTrue("${feeling.id} read back as ${back!!.id}", back.id.split("+").first() == feeling.id)
        }
    }

    @Test fun `a weak single word is not enough`() {
        assertNull(FeelingInterpreter.interpret("low"))
    }

    @Test fun `negation points the other way`() {
        assertEquals("sad", FeelingInterpreter.interpret("not happy today")?.id)
    }

    @Test fun `two strong feelings blend`() {
        val feeling = FeelingInterpreter.interpret("I just got dumped but I'm hopeful")
        assertNotNull(feeling)
        assertTrue(feeling!!.id.contains("+"))
        assertTrue(feeling.queries.size in 2..3)
    }
}
